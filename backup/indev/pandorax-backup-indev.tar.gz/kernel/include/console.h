#ifndef __CONSOLE_H__
#define __CONSOLE_H__

#include "types.h"

#define screen_width 120
#define screen_height 70
Uint8 *ram = (Uint8 *)0xB8000; /* Video ram */
Upoint2d cursor = {0,0};

void clear_screen();
void print_string(string str,int8 color);
void update_cursor();

void clear_screen()
{
  unsigned int i = 0;
  while(i<=screen_width*screen_height)
    {
      ram[i] = 0;
      i++;
    }
  cursor.x = 0;
  cursor.y = 0;
}

void print_string(string str, int8 color)
{
  unsigned int i = 0;
  while(*str!=0)
    {
      /*if(i>=80) break; For debugging reasons */
      update_cursor();
      ram[i] = *str;
      str = str + 1;
      i++;
      ram[i] = color;
      i++;
      cursor.x = cursor.x + 2;
    }
}

void update_cursor()
{
  if(cursor.x>=80)
    {
      cursor.y++;
      cursor.x = cursor.x - 80;
      update_cursor();
    }
}

#endif /* console.h */
