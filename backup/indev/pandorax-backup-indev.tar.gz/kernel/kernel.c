/* PandoraX operating system kernel. */
/* Started the 17th of July 2012     */

#include "include/console.h"

#define MAGIC_PRM 0x2BADB002

void kmain(void)
{
  extern Uint32 magic;
  extern void *mbd;
  clear_screen();
  if(magic != MAGIC_PRM)
    {
      /* Something weird went wrong */
      print_string("Error: Magic number is invalid.", 0x07);
    }
  else
    {
      print_string("Hello, World!",0x07);
    }
  while(1) {/* Nothing */}
 /* So the processor doesn't execute junk after this file */
}
